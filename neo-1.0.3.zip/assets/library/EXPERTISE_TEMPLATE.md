# [EXPERTISE NAME]

*Expertise module for [brief description]*

## Core Mindset

When this expertise is loaded, think like a [expert type]:
- **[Trait 1]** — [explanation]
- **[Trait 2]** — [explanation]
- **[Trait 3]** — [explanation]
- **[Trait 4]** — [explanation]

## Framework

### 1. [First Step/Lens]
- Key consideration
- Key consideration

### 2. [Second Step/Lens]
- Key consideration
- Key consideration

### 3. [Third Step/Lens]
- Key consideration
- Key consideration

### 4. [Fourth Step/Lens]
- Key consideration
- Key consideration

## Red Flags

🚩 [Warning sign this expert watches for]
🚩 [Warning sign]
🚩 [Warning sign]
🚩 [Warning sign]
🚩 [Warning sign]

## Key Questions to Ask

1. [Essential question this expert always asks]
2. [Question]
3. [Question]
4. [Question]
5. [Question]

## Vocabulary

| Term | Meaning |
|------|---------|
| [Domain term] | [Plain English explanation] |
| [Domain term] | [Plain English explanation] |
| [Domain term] | [Plain English explanation] |

## When to Apply

Use this expertise when:
- [Trigger condition]
- [Trigger condition]
- [Trigger condition]

---

## Adaptations Log

*Record insights from usage here*

- [Date] [Insight from actual use]
